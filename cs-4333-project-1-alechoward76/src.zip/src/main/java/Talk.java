package main.java;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.*;


import org.checkerframework.checker.guieffect.qual.UI;

/** Driver class for the Talk socket application. */
public class Talk {

  /*public static void main(String[] args) {
    // TODO: complete main - should call autoMode, clientMode, helpMode, and serverMode
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter Command");
    String uInput = sc.nextLine();//User Input
    sc.close();
    String[] arr = uInput.split(" ");
    int portNum = 12987; //default value of portNum
    
    
    if (arr.length == 4){//Changes portNum if user provides one
      portNum = Integer.parseInt(arr[3]);
    }

   // System.out.println("PortNum: " + portNum);
    

    if (uInput.charAt(6) == 'h' && uInput.charAt(7) == ' '){
      System.out.println("clientMode");
      clientMode(arr[2], portNum);//calls clientMode with the args of hostname,portnum
    }else if (uInput.charAt(6) == 's'){

      System.out.println("serverMode");
      serverMode(portNum);

    }else if (uInput.charAt(6) == 'a'){
      System.out.println("autoMode");
      autoMode(arr[2], portNum);

    }else if(uInput.charAt(6) == 'h' && uInput.charAt(7) == 'e'){
      //System.out.println("helpMode");
      helpMode();
    }else{
      System.out.println("Invalid Input");
      System.exit(0);
    }

  }*/

  /**
   * The program enters auto mode and behaves as a client attempting to connect to the specified
   * host on the specified port. If the host is not available, the program should behave as a
   * server listening for connections on the specified port.
   * @param hostname the host to connect to
   * @param portnumber the port to connect to or listen on
   * @return {@code false} if the host and port are both unavailable
   * @throws never should return {@code false} rather than throwing an exception
   */
  private static boolean autoMode(String hostname, int portnumber) {
    // TODO: complete autoMode - should call clientMode and serverMode
    if (clientMode(hostname, portnumber) != false){
       
        clientMode(hostname, portnumber);//Calls clientMode if host is available
    }else if (clientMode(hostname, portnumber) == false){
      if (serverMode(portnumber) != false){
        serverMode(portnumber);//calls serverMode if host is unavailable, but port is.
      }
        
    }

    System.out.println("Client unable to communicate with server & Server unable to listen on specified port");
    return false;//returns false if neither host or port are available
  }

  /**
   * The program behaves as a client connecting to the specified host on the specified port.
   * @param hostname the host to connect to
   * @param portnumber the port to connect to
   * @return {@code false} if the host is not available
   * @throws never should return {@code false} rather than throwing an exception
   */
  private static boolean clientMode(String hostname, int portnumber) {
    try {
      return Talk.clientMode(new TalkClient(hostname, portnumber));
    } catch (IOException e) {
      
      return false;
    }
  }

  /**
   * The program behaves as a client with the specified client connection.
   * @param client the client interface to use for socket communication
   * @return {@code false} if the host is not available
   * @throws never should return {@code false} rather than throwing an exception
   */
  private static boolean clientMode(BasicTalkInterface client) {
    // TODO: complete clientMode

    if (client.status().contains("shit")){
      System.out.println("Client unable to communicate with server");
      return false;
    }
    try{
      
      client.asyncIO();
    }catch(IOException e){
      return false;
    }
    return true;
    
    
    
    
  }

  /**
   * Should print your name and instructions on how to use the talk program. Instructions must
   * at least include the line "Talk [-a | –h | -s] [hostname | IPaddress] [–p portnumber]"
   */
  private static void helpMode() {
    // TODO: complete helpMode
    System.out.println("Alec Howard");
    System.out.println("Talk [-a | -h | -s] [hostname | IPaddress] [-p portnumber]");
  }

  /**
   * The program behaves as a server listening for connections on the specified port.
   * @param portnumber the port to listen for connections on
   * @return {@code false} if the port is unavailable
   * @throws never should return {@code false} rather than throwing an exception
   */
  private static boolean serverMode(int portnumber) {
    try {
      return Talk.serverMode(new TalkServer(portnumber));
    } catch (IOException e) {
      return false;
    }
  }

  /**
   * The program behaves as a server with the specified server.
   * @param server the server interface to use for socket communication
   * @return {@code false} if the port is not available
   * @throws never should return {@code false} rather than throwing an exception
   */
  private static boolean serverMode(BasicTalkInterface server)  {
    // TODO: complete serverMode
    /*if (server.status() != "shit"){
      //server.syncIO();
    }*/
    System.out.println("Server unable to listen on specified port");
    return false;
  }
public boolean start(String[] args){
  return false;
}

  public static void main(String[] args){
    System.exit(new Talk().start(args) ? 0 : 1);
  }
}